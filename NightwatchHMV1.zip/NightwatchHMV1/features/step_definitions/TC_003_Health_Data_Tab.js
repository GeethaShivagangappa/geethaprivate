var action = require('./ReusableTests.js');
var Objects = require(__dirname+'/../../repository/HarmonisePages.js');
var context;

module.exports = function () {
    this.Given(/^User is on the Health Page$/, function () {
        context = this;
        action.performClick("HomePage|linkMenu", function () {
            action.performClick("HomePage|linkHealthMenuSelect", function(){
                action.isDisplayed("HealthPage|chartHeartMeter", function () {

                });
            });
        });

    });

    this.Given(/^Physical Priorities popup displays the already set values$/, function () {
        action.readListData('//*[@data-section="PhysicalPriorities"]/ol/li/span', function (data){
            action.performClick("HealthPage|linkPlusIconPhyPriority", function () {
                action.readListData('((//div[@class="priorities"])[last()]//li/a/span[2])', function (popupData){
                    console.log('Expected: '+ popupData);
                    console.log('  Actual: '+ data);
                    context.verify.equal(data, popupData);
                });
            })
        });
    });

    this.Given(/^Update the values in Physical Priorities modules and validate$/, function () {
        action.dragAndDropOverAnotherElement('(//a[@class="item-select-anchor"])[last()]','(//a[@class="item-select-anchor"])[last()-4]', function () {
            action.dragAndDropOverAnotherElement('(//a[@class="item-select-anchor"])[last()-1]','(//a[@class="item-select-anchor"])[last()-3]', function () {
                action.readListData('((//div[@class="priorities"])[last()]//li/a/span[2])', function (afterRearrange){
                    action.performClick("HealthPage|buttonRecordNewData", function () {
                        context.pause(2000);
                        action.performClick("HealthPage|tabData", function () {
                            context.pause(2000);
                            action.readListData('//*[@data-section="PhysicalPriorities"]/ol/li/span', function (saveData) {
                                console.log('Expected: '+ afterRearrange);
                                console.log('  Actual: '+ saveData);
                                context.verify.equal(afterRearrange, saveData);
                            });
                        })
                    });
                });
            });
        });
    });

    this.Given(/^BMI popup displays the already set values$/, function () {
        action.readListData('//div[@data-section="BMI"]//li/span/span', function (bmi_data){
            action.performClick("HealthPage|linkPlusIconBMI", function () {
                context.pause(2000);
                action.getInputBoxText("HealthPage|inputStoneBMI", function (stone_data) {
                    action.getInputBoxText("HealthPage|inputLbsBMI", function (lbs_data) {
                        action.getInputBoxText("HealthPage|inputftsBMI", function (ft_data) {
                            action.getInputBoxText("HealthPage|inputInchsBMI", function (inch_data) {
                                action.getText("HealthPage|labelBMIReadingNumber", function (bmi_number_data) {
                                    action.getText("HealthPage|labelBMIReadingStatus", function (bmi_status_data) {
                                        var popup_data = Math.round(Math.fround(stone_data)*100)/100 + ' stone '
                                            + (Math.round(Math.fround(lbs_data)*100)/100).toFixed(1) + ' lbs-'
                                            + Math.round(Math.fround(ft_data)*100)/100 + ' ft. '
                                            + (Math.round(Math.fround(inch_data)*100)/100).toFixed(1) + ' in.-'
                                            + (Math.round(Math.fround(bmi_number_data)*100)/100).toFixed(1) + ' (' + bmi_status_data+ ')';
                                        console.log('Expected: '+ bmi_data);
                                        console.log('  Actual: '+ popup_data);
                                        context.verify.equal(bmi_data, popup_data);
                                    });
                                });
                            });
                        });
                    }) ;
                });
            });
        });
    });

    this.Given(/^Update the values in BMI modules and validate$/, function () {
        action.fnRandomInteger(8, 15, function (stone) {
            action.setText("HealthPage|inputStoneBMI", stone);
            action.fnRandomInteger(1, 14, function (lbs) {
                action.setText("HealthPage|inputLbsBMI", lbs);
                action.fnRandomInteger(4, 9, function (ft) {
                    action.setText("HealthPage|inputftsBMI", ft);
                    action.fnRandomInteger(1, 11, function (inch) {
                        action.setText("HealthPage|inputInchsBMI", inch);
                        action.performClick("HealthPage|buttonRecalculateBMI", function () {
                            context.pause(2000);
                            action.getText("HealthPage|labelBMIReadingNumber", function (bmi_number) {
                                action.getText("HealthPage|labelBMIReadingStatus", function (health_status) {
                                    action.performClick("HealthPage|buttonRecordNewData", function () {
                                        context.pause(2000);
                                        action.performClick("HealthPage|tabData", function () {
                                            context.pause(2000);
                                            action.readListData('//div[@data-section="BMI"]//li/span/span', function (saveData) {
                                                var popup_data = Math.round(Math.fround(stone) * 100) / 100 + ' stone '
                                                    + (Math.round(Math.fround(lbs) * 100) / 100).toFixed(1) + ' lbs-'
                                                    + Math.round(Math.fround(ft) * 100) / 100 + ' ft. '
                                                    + (Math.round(Math.fround(inch) * 100) / 100).toFixed(1) + ' in.-'
                                                    + (Math.round(Math.fround(bmi_number) * 100) / 100).toFixed(1) + ' (' + health_status + ')';
                                                console.log('Expected: ' + popup_data);
                                                console.log('  Actual: ' + saveData);
                                                context.verify.equal(popup_data, saveData);
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    this.Given(/^Activity Level popup displays the already set values$/, function () {
        action.readListData('//div[@data-section="ActivityLevel"]//li/span/span', function (activity_data) {
            action.readListData('//ul[@class="activity-level-workout-list"]//span', function (exercise_data) {
                action.performClick("HealthPage|linkPlusIconActivity", function () {
                    context.pause(2000);
                    action.getText("HealthPage|labelPopupActivityWorkoutFirstSelection", function (first_select) {
                        action.getText("HealthPage|labelPopupActivityWorkoutSecondSelection", function (second_select) {
                            action.getText("HealthPage|labelPopupActivityWorkoutThirdSelection", function (third_select) {

                                var workout_popup_data = first_select + '-' + second_select + '-' + third_select;
                                workout_popup_data = workout_popup_data.replace('--', '');
                                if(workout_popup_data.charAt(0) == '-') workout_popup_data = workout_popup_data.substring(1, workout_popup_data.length-1);
                                console.log('Expected: ' + workout_popup_data);
                                console.log('  Actual: ' + exercise_data);
                                context.verify.equal(workout_popup_data, exercise_data);
                            });
                        });
                    });
                });
            });
        });
    });

    this.Given(/^Update the values in Activity Level modules and validate$/, function () {

    });

    this.Given(/^Heart Health popup displays the already set values$/, function () {
        var blood_data_locator = Objects.sections.HealthPage.elements.listBloodData.selector;
        var cholestrol_data_locator = Objects.sections.HealthPage.elements.listCholesterolData.selector;
        action.readListData(blood_data_locator, function (blood_data) {
            action.readListData(cholestrol_data_locator, function (cholestrol_data) {
                action.performClick("HealthPage|linkPlusIconHeartHealth", function () {
                    context.pause(2000);
                    action.getInputBoxText("HealthPage|inputSystolic", function (systolic) {
                        action.getInputBoxText("HealthPage|inputDiastolic", function (diastolic) {
                            action.getInputBoxText("HealthPage|inputTotalCholesterol", function (total_cholesterol) {
                                action.getInputBoxText("HealthPage|inputTriglycerides", function (triglycerides) {
                                    action.getInputBoxText("HealthPage|inputLDLCholesterol", function (ldlCholesterol) {
                                        action.getInputBoxText("HealthPage|inputHDLCholesterol", function (hdlCholesterol) {
                                            action.getInputBoxText("HealthPage|inputBloodType", function (blood_group) {
                                                var heart_data = systolic + ' systolic over ' + diastolic + ' diastolic-' + blood_group + '-'
                                                    + total_cholesterol + ' mmol/L Total Cholesterol-' + triglycerides + ' mmol/L Triglycerides-'
                                                    + ldlCholesterol + ' mmol/L LDL Cholesterol-' + hdlCholesterol + ' mmol/L HDL Cholesterol';
                                                var saved_heart_data = blood_data + '-' + cholestrol_data;
                                                heart_data = heart_data.replace('Positive', '+');
                                                heart_data = heart_data.replace('Negative', '-');
                                                console.log('Expected: ' + heart_data);
                                                console.log('  Actual: ' + saved_heart_data);
                                                context.verify.equal(heart_data, saved_heart_data);
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    this.Given(/^Update the values in Heart Health modules and validate$/, function () {
        var bloodGroupLocator = Objects.sections.HealthPage.elements.selectBloodType.selector;
        var blood_data_locator = Objects.sections.HealthPage.elements.listBloodData.selector;
        var cholestrol_data_locator = Objects.sections.HealthPage.elements.listCholesterolData.selector;
        action.fnRandomInteger(70, 150, function (systolic) {
            action.setText("HealthPage|inputSystolic", systolic);
            action.fnRandomInteger(40, 60, function (diastolic) {
                action.setText("HealthPage|inputDiastolic", diastolic);
                action.randomSelectDropdown(bloodGroupLocator, function (blood_group) {
                    action.fnRandomInteger(2, 9, function (total_ch) {
                        action.setText("HealthPage|inputTotalCholesterol", total_ch);
                        action.fnRandomInteger(2, 9, function (trig) {
                            action.setText("HealthPage|inputTriglycerides", trig);
                            action.fnRandomInteger(2, 9, function (ldl) {
                                action.setText("HealthPage|inputLDLCholesterol", ldl);
                                action.fnRandomInteger(2, 9, function (hdl) {
                                    action.setText("HealthPage|inputHDLCholesterol", hdl);
                                    context.pause(1000);
                                    action.performClick("HealthPage|buttonRecordNewData", function () {
                                        context.pause(4000);
                                        action.performClick("HealthPage|tabData", function () {
                                            context.pause(2000);
                                            action.readListData(blood_data_locator, function (blood_data) {
                                                action.readListData(cholestrol_data_locator, function (cho_data) {
                                                    var popup_data = systolic + ' systolic over ' + diastolic + ' diastolic-' + blood_group + '-'
                                                        + total_ch + ' mmol/L Total Cholesterol-' + trig + ' mmol/L Triglycerides-'
                                                        + ldl + ' mmol/L LDL Cholesterol-' + hdl + ' mmol/L HDL Cholesterol';;
                                                    var saved_data = blood_data + '-' + cho_data;
                                                    console.log('Expected: ' + popup_data);
                                                    console.log('  Actual: ' + saved_data);
                                                    context.verify.equal(popup_data, saved_data);
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        })
    });

    this.Given(/^Hold Your Breadth popup displays the already set values$/, function () {
        action.isDisplayed("HealthPage|labelHoldYourBreadthReading", function () {
            context.pause(1000);
        })

    });

    this.Given(/^Update the values in Hold Your Breadth modules and validate$/, function () {
        var stopwatch_reading_locator = Objects.sections.HealthPage.elements.listStopwatchReading.selector;
        action.performClick("HealthPage|linkPlusIconHoldYourBreath", function () {
            context.pause(2000);
            action.performClick("HealthPage|buttonStopwatchStartStop", function () {
                context.pause(2000);
                action.fnRandomInteger(8, 12, function (wait_seconds) {
                    context.pause(wait_seconds*1000);
                    action.performClick("HealthPage|buttonStopwatchStartStop", function () {
                        context.pause(2000);
                        action.readListData(stopwatch_reading_locator, function (stopwatch_reading) {
                            action.performClick("HealthPage|buttonRecordNewData", function () {
                                context.pause(2000);
                                action.performClick("HealthPage|tabData", function () {
                                    context.pause(2000);
                                    action.getText("HealthPage|labelHoldYourBreadthReading", function (saved_reading) {
                                        var array = stopwatch_reading.split('-');
                                        stopwatch_reading = array[0] +' Minute, '+ array[1] +' seconds, '+ array[2] + ' ms';
                                        console.log('Expected: ' + stopwatch_reading);
                                        console.log('  Actual: ' + saved_reading);
                                        context.verify.equal(stopwatch_reading, saved_reading);
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    this.Given(/^Body Shape popup displays the already set values$/, function () {
        action.getText("HealthPage|labelBodyShaped", function (body_shape) {
            action.performClick("HealthPage|linkPlusIconBodyShape", function () {
                context.pause(2000);
                action.getText("HealthPage|labelSelectedBodyShape", function (selected_body_shape_popup) {
                    console.log('Expected: ' + body_shape);
                    console.log('  Actual: ' + selected_body_shape_popup);
                    context.verify.equal(body_shape, selected_body_shape_popup);
                })
            })
        })

    });

    this.Given(/^Update the values in Body Shape modules and validate$/, function () {
        action.fnRandomInteger(1, 4, function (index) {
            var body_selector = Objects.sections.HealthPage.elements.buttonDifferrentBodyShape.selector.replace("<<type>>",index);
            context.useXpath().click(body_selector);
            context.pause(1000);
            action.getText("HealthPage|labelSelectedBodyShape", function (body_shape_popup) {
                action.performClick("HealthPage|buttonRecordNewData", function () {
                    context.pause(2000);
                    action.performClick("HealthPage|tabData", function () {
                        context.pause(2000);
                        action.getText("HealthPage|labelBodyShaped", function (body_shape) {
                            console.log('Expected: ' + body_shape_popup);
                            console.log('  Actual: ' + body_shape);
                            context.verify.equal(body_shape_popup, body_shape);
                        });
                    });
                });
            });
        });
    });
};

