var action = require('./ReusableTests.js')
var context;
module.exports = function() {

    this.When(/^the user navigates to the last screen$/, function () {
        context = this;
        action.performClick('LoginPage|buttonSkip');
       // action.pause(2000);
        action.performClick('LoginPage|buttonSkip');
       //action.pause(2000);
        action.performClick('LoginPage|buttonSkip');
       // action.pause(2000);

    });

    this.When(/^the user fill all the details and clicks next button$/, function () {

        action.selectDropdown('LoginPage|dropdownMaritalStatus', 'LoginPage|dropdownOptionCohabiting')

        action.selectDropdown('LoginPage|dropdownHome', 'LoginPage|dropdownOptionOwn')

        action.setText('LoginPage|dropdownHome',"q2qa14.eptest.admin2@gisqa.mercer.com")

        action.selectDropdown('LoginPage|dropdown', 'LoginPage|dropdownOptionGreat')

        action.selectDropdown('LoginPage|dropdown', 'LoginPage|dropdownOptionHealth')

        action.selectDropdown('LoginPage|dropdown', 'LoginPage|dropdownOptionPension')

        action.performClick('LoginPage|buttonNext')

        action.performClick('LoginPage|buttonContinue')
    });
}