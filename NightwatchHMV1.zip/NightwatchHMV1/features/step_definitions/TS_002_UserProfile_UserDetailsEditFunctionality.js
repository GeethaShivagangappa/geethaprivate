
var action = require('./ReusableTests.js')

module.exports = function() {

    this.Given(/^Validate Profile Update on About me section$/, function () {
        action.randomSelectDropdown('maritalDropdown', function (maritalStatus) {
            action.randomSelectDropdown('genderDropdown', function (gender) {
                action.wait_a_Second();
                action.performClick('ProfilePage|buttonAboutMeSave', function () {
                    action.isDisplayed('ProfilePage|labelInfoSaveSuccess', function () {
                        action.verifyText('ProfilePage|labelMaritalStatus', maritalStatus)
                        action.verifyText('ProfilePage|labelGender', gender);
                    }); 
                });
            });
        });
    });

    this.Given(/^Validate Profile Update on Address section$/, function () {
        action.randomSelectDropdown('ownershipDropdown', function (ownership) {
            action.click('ProfilePage|buttonAddressSave');
            action.isDisplayed('ProfilePage|labelInfoSaveSuccess', function () {
                action.verifyText('ProfilePage|labelOwnership', ownership)
            });
        });
    });

    this.Given(/^Validate Profile Update on Contact section$/, function () {

        action.fnRandomEmailId(function (email) {
            action.fnRandomPhoneNumber(function (phone) {
                action.wait_a_Second()
                console.log(email)
                console.log(phone)
                action.setText('ProfilePage|inputHomeEmailId', email);
                action.setText('ProfilePage|InputPhoneNumber', phone);
                action.wait_a_Second()
                action.performClick('ProfilePage|buttonContactSave', function () {
                    action.verifyText('ProfilePage|labelPersonalEmail', email)
                    action.verifyText('ProfilePage|labelPhoneNumber', phone)
                });
            });
        });
    });

    this.Given(/^Validate Profile Update on Family section$/, function () {
        action.wait_a_Second()
        action.fnRandomInteger(21, 45, function (age) {
            action.fnRandomInteger(2154, 45097, function (salary) {
                action.setText('ProfilePage|inputPartnerAge', age);
                action.setText('ProfilePage|inputPartnerSalary', salary);
                action.setText('ProfilePage|inputNoOfChildren', '1');
                action.performClick('ProfilePage|inputPartnerSalary', function () {
                    
                });

                /*action.selectDate('ProfilePage|inputChild1DOB', '9-Nov-2016', function (result) {
                 console.log(result)
                 action.wait_a_bit_long();
                 });
                 action.wait_a_Second();
                 action.click('ProfilePage|buttonFamilySave');
                 action.wait_a_Second();
                 action.verifyText('ProfilePage|labelPartnerAge', age);
                 action.verifyText('ProfilePage|labelPartnerSalary', salary)*/
            });
        });

    });

    this.Given(/^Validate Profile Update on Rate Knowledge section$/, function () {
        action.wait_a_Second();

        action.randomSelectDropdown('sophisticationDropdown', function (pfValue) {
            action.randomSelectDropdown('interestDropdown', function (lsValue) {
                action.randomSelectDropdown('concernDropdown', function (mwValue) {
                    action.wait_a_Second();
                    //action.click('ProfilePage|buttonRateKnwldgSave');
                    this.click('div[data-id="knowledge"] button');
                    action.wait_a_Second();
                    action.verifyText('ProfilePage|labelUnderstandPersonalFinance', pfValue);
                    action.verifyText('ProfilePage|labelLearningScope', lsValue)
                    action.verifyText('ProfilePage|labelWorriedMost', mwValue)
                });
            });
        });
    });

}
