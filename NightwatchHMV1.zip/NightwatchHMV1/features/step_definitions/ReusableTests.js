var data = require('../../TestResources/GlobalTestData')

var LoginPage, HomePage, HealthPage, page, context;

function initializePageObjects(context, callback){
    var HarmonisePage = context.page.HarmonisePages()

    page = HarmonisePage.section
    LoginPage = HarmonisePage.section.LoginPage
    HomePage = HarmonisePage.section.HomePage
    HealthPage = HarmonisePage.section.HealthPage
    callback();
}

module.exports = function(){

    this.Given(/^Once User is logged in using "([^"]*)"$/, function (userType) {
        var URL;
        context = this;
        var execEnv = data["TestingEnvironment"];
        console.log('Test Environment: ' +execEnv);
        if(execEnv.toUpperCase() == "QA") {
            URL = data.urlHarmoniseQA;
            var userDB = data.usersQA[userType]
        }
        else{
            URL = data.urlHarmoniseUAT
            var userDB = data.usersUAT[userType]
        }
        initializePageObjects(context, function () {
            context.maximizeWindow()
                .deleteCookies()
                .url(URL);
            context.timeoutsImplicitWait(30000);
            LoginPage.waitForElementVisible('@inputUsername', data.longWait)
            LoginPage.setValue('@inputUsername', userDB.username)
            LoginPage.click('@buttonNext');

            LoginPage.waitForElementVisible('@inputPassword', data.longWait)
            LoginPage.setValue('@inputPassword', userDB.password)
            LoginPage.click('@buttonLogin', function () {
                    HomePage.waitForElementVisible('@labelGreeting', data.longWait)
            });
        });
    });

    this.When(/^User Clicks on "([^"]*)" Link or Button$/, function (locator) {
        context.pause(1000);
        performClick(locator, function () {
            context.pause(1000);
        });
    });

    this.Then(/^"([^"]*)" page or message should be displayed$/, function(locator){
        isDisplayed(locator, function () {
            context.pause(1000)
        });
    });

    this.When(/^Enter "([^"]*)" field with "([^"]*)" value$/, function (locator, value) {
        setText(locator, value)
    });

    this.When(/^Select "([^"]*)" in "([^"]*)" dropdown$/, function (value, locator) {
        //selectDropdown(locator, value, function (callback) {})
        selectDropdown(locator, value);
    });

    this.When(/^Randomly select in "([^"]*)" dropdown$/, function (locator, callback) {
        randomSelectDropdown(locator, function (selectedValue) {
            callback(selectedValue);
        });
    });

    this.When(/^Select "([^"]*)" in "([^"]*)" dropdown as user$/, function (value, locator) {
        selectDropdownUI(locator, value);
    });

    this.Then(/^"([^"]*)" alert should be displayed$/, function(txt){
        verifyAlert(txt, this);
    });
}

var scroll = function (locator, callback) {
    var pageAndObject = locator.split("|");
    var pg = pageAndObject[0];
    var obj = '@'+pageAndObject[1];

    page[pg].getLocation(obj, function (position) {
        context.execute(function (x, y) {
            window.scrollTo(x - 300, y - 300);
            return true
        }, [position.value.x, position.value.y]);
        callback();
    });
}

var verifyAlert = function(txt, context){
    context.getAlertText(function(alertText){
        context.assert.equal(alertText.value, txt)
    });
    context.acceptAlert();
}

var isDisplayed = function (locator, callback) {
    context.pause(data.shortWait);
    var pageAndObject = locator.split("|")
    var mpage = pageAndObject[0];
    var object = '@'+pageAndObject[1];
    page[mpage].waitForElementVisible(object, data.longWait, function () {
        callback()
    })
}

var getText = function (locator, callback) {
    var pageAndObject = locator.split("|")
    var mpage = pageAndObject[0]
    var object = '@'+pageAndObject[1]
    page[mpage].getText(object, function (result) {
        return callback(result.value)
    })
}

var setText = function (locator, data) {
    var pageAndObject = locator.split("|")
    var mpage = pageAndObject[0]
    var object = '@'+pageAndObject[1]
    var value = data.toString();
    page[mpage].clearValue(object)
    if(value.startsWith("TestingEnvironment")){
        if(data["TestingEnvironment"].toUpperCase() == "QA")
            userCred = data.usersQA.normalUser
        else
            userCred = data.usersUAT.normalUser
        var key = value.split("|")[1]
        page[mpage].setValue(object, userCred[key])
    }else{
        if(value.startsWith("fnRandomEmailId")){
            fnRandomEmailId(function (response) {
                value = response;
            });
        }else if(value.startsWith("fnRandomPhoneNumber")){
            fnRandomPhoneNumber(function (response) {
                value = response;
            });
        }else{
           // console.log(value);
            page[mpage].setValue(object, value)
        }
    }
}

var fnRandomEmailId = function fnRandomEmailId(callback) {
    var max = 9, min = 0, str="", i;
    for(i=0; i < 5; i++){
        str = str + Math.floor(Math.random() * (max - min) + min);
    }
    return callback('email'+ str +'@mercer.com');
}

var fnRandomPhoneNumber = function fnRandomPhoneNumber(callback) {
    var max = 9, min = 0, str="", i;
    for(i=0; i < 10; i++){
        str = str + Math.floor(Math.random() * (max - min) + min);
    }
    return callback(str);
}

var wait_a_Second = function () {
    context.pause(data.shortWait)
}

var wait_a_bit_long = function () {
    context.pause(data.longWait)
}

var verifyText = function (locator, value) {
    var pageAndObject = locator.split("|")
    var mpage = pageAndObject[0]
    var object = '@'+pageAndObject[1]
    //page[mpage].verify.containsText(object, value);
    page[mpage].getText(object, function (response) {
        console.log("Excepted: "+ response.value.toUpperCase());
        console.log("Actual: "+ value.toUpperCase());
        context.assert.equal(response.value.toUpperCase(), value.toUpperCase())
        if(response.value.toUpperCase() != value.toUpperCase()){
            console.log("Text Content mismatch: ");
        }
    });
};

var performClick = function (locator, callback) {
    var pageAndObject = locator.split("|");
    var mpage = pageAndObject[0];
    var object = '@'+pageAndObject[1];

    scroll(locator, function () {
        page[mpage].click(object);
        callback();
    });
};

var selectDropdownUI = function(locator, value, callback) {
    var pageObject = locator.split("|")
    var mpage = pageObject[0]
    var object = '@' + pageObject[1];
    page[mpage].click(object)
    context.pause(2000)
    var valueObject = value.split("|")
    var vpage = valueObject[0]
    var vobj = '@'+valueObject[1]
    page[vpage].waitForElementVisible(vobj, data.longWait)
    page[vpage].click(vobj)
    context.pause(1000)
    page[vpage].click(vobj)
    context.pause(1000)
    context.keys(context.Keys.ENTER);
    context.pause(1000)
};

var fnRandomInteger = function fnRandomPhoneNumber(min, max, callback) {
    var random = Math.floor(Math.random() * (max - min) + min);
    return callback(random);
}

var selectDropdown = function (identifier, value) {
    wait_a_Second();
    context.execute(function (identifier, value) {

        var objSelect = document.getElementById(identifier);
        setSelectedValue(objSelect, value);
        function setSelectedValue(selectObj, valueToSet) {
            for (var i = 0; i < selectObj.options.length; i++) {
                if (selectObj.options[i].text== valueToSet) {
                    selectObj.options[i].selected = true;
                    return;
                }
            }
        }
    }, [identifier, value], function (result) {});
}

var randomSelectDropdown1 = function (identifier, callback) {
    wait_a_Second();
    context.execute(function (identifier) {

        var objSelect = document.getElementById(identifier);

        var text = objSelect.options[objSelect.selectedIndex].text;
        var value='null';
        var ddlArray= new Array();
        for (var i = 0; i < objSelect.options.length; i++) {
            ddlArray[i] = objSelect .options[i].text;
        }

        while(true){
            var index = Math.floor(Math.random() * (ddlArray.length-1));
            if(ddlArray[index] != text){
                value = ddlArray[index];
                break;
            }
        }

        setSelectedValue(objSelect, value);
        function setSelectedValue(selectObj, valueToSet) {
            for (var i = 0; i < selectObj.options.length; i++) {
                if (selectObj.options[i].text== valueToSet) {
                    selectObj.options[i].selected = true;
                    return;
                }
            }
        }

        setTimeout(function(){  }, 2000);

        return objSelect.options[objSelect.selectedIndex].text;
    }, [identifier], function (result) {
        callback(result.value)
    });
}

var randomSelectDropdown = function (locator, callback) {
    context.element('xpath', locator, function (obj) {
        var objSelect = obj.value;
            context.execute(function (objSelect) {

                var text = objSelect.options[objSelect.selectedIndex].text;
                var value = 'null';
                var ddlArray = new Array();
                for (var i = 0; i < objSelect.options.length; i++) {
                    ddlArray[i] = objSelect.options[i].text;
                }

                while (true) {
                    var index = Math.floor(Math.random() * (ddlArray.length - 1));
                    if (ddlArray[index] != text) {
                        value = ddlArray[index];
                        break;
                    }
                }

                setSelectedValue(objSelect, value);
                function setSelectedValue(selectObj, valueToSet) {
                    for (var i = 0; i < selectObj.options.length; i++) {
                        if (selectObj.options[i].text == valueToSet) {
                            selectObj.options[i].selected = true;
                            return;
                        }
                    }
                }

                setTimeout(function () {
                }, 2000);

                return objSelect.options[objSelect.selectedIndex].text;
            }, [objSelect], function (result) {
                callback(result.value)
            });
    });
}

var highlight = function(){
    client.execute(function(target){
        target.style.backgroundColor = "red";
    }, [element]);
}

var readListData = function (locator, callback) {
    var data = "", count = 0;
    context.elements('xpath', locator, function(webElementsArray) {
        count = webElementsArray.value.length;
        webElementsArray.value.forEach(function (webEle) {
            context.elementIdText(webEle.ELEMENT, function (result) {
                count--;
                data = data + '-' + result.value
                if (count <= 0) {
                    data = data.substring(1, data.length);
                    callback(data);
                }
            });
        });
    });
};

var dragAndDropOverAnotherElement = function (webElement1, webElement2, callback) {
    context.useXpath()
    context.moveToElement(webElement1,  0,  0)
    context.mouseButtonDown(0)
    context.moveToElement(webElement2,  0,  0)
    context.mouseButtonUp(0)
    context.pause(2000);
    callback();
}

var getInputBoxText = function (locator, callback) {
    var pageAndObject = locator.split("|")
    var mpage = pageAndObject[0]
    var object = '@'+pageAndObject[1]
    page[mpage].getValue(object, function (result) {
        return callback(result.value)
    })
}


module.exports.selectDropdownUI = selectDropdownUI;
module.exports.selectDropdown = selectDropdown;
module.exports.randomSelectDropdown = randomSelectDropdown;
module.exports.randomSelectDropdown1 = randomSelectDropdown1;
module.exports.performClick = performClick;
module.exports.getText = getText;
module.exports.setText = setText;
module.exports.isDisplayed = isDisplayed;
module.exports.verifyText = verifyText;
module.exports.wait_a_Second = wait_a_Second;
module.exports.wait_a_bit_long = wait_a_bit_long;
module.exports.fnRandomPhoneNumber = fnRandomPhoneNumber;
module.exports.fnRandomEmailId = fnRandomEmailId;
module.exports.verifyAlert = verifyAlert;
module.exports.fnRandomInteger = fnRandomInteger;
module.exports.readListData = readListData;
module.exports.dragAndDropOverAnotherElement = dragAndDropOverAnotherElement;
module.exports.getInputBoxText = getInputBoxText;
module.exports.highlight = highlight;
