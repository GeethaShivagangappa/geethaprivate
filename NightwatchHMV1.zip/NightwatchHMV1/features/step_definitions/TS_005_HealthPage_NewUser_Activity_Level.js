var action = require('./ReusableTests.js')

module.exports = function(browser) {

    this.When(/^the user moves across the fitness level slider$/, function () {



            action.isDisplayed('HealthPage|sliderFitnessLevel')

            action.wait_a_Second()

            action.click('HealthPage|sliderButtonFitnessLevel')

            action.setText('HealthPage|sliderButtonFitnessLevel', browser.keys.arrowRight)


    })




}
