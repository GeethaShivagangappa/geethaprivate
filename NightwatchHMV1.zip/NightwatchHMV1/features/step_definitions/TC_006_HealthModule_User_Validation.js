
var action = require('./ReusableTests.js')
var Objects = require(__dirname+'/../../repository/HarmonisePages.js');
var context;

module.exports = function () {
    var maritalStatus, gender
    this.Given(/^User can enter the value in Pulserate input field$/, function () {

console.log("Entered")

        action.setText('HealthPage|inputPulserateValue', 232);
        action.wait_a_Second()

            });



    this.Given(/^Drag and Drop the elements$/, function () {
        action.dragAndDropOverAnotherElement('(//a[@class="item-select-anchor"])[last()]','(//a[@class="item-select-anchor"])[last()-4]', function () {
            action.dragAndDropOverAnotherElement('(//a[@class="item-select-anchor"])[last()-1]','(//a[@class="item-select-anchor"])[last()-3]', function () {

            });
        });
    });

    this.Given(/^Validate Profile Update on Contact section$/, function () {
        var contactInfo;

        action.fnRandomEmailId(function (email) {
            action.fnRandomPhoneNumber(function (phone) {
                action.setText('ProfilePage|inputHomeEmailId', email);

                action.setText('ProfilePage|InputPhoneNumber', phone);

                action.click('ProfilePage|buttonContactSave');

                action.wait_a_Second()

                action.getText('ProfilePage|labelPersonalEmail', function (response) {
                    contactInfo = response;

                    action.getText('ProfilePage|labelPersonalEmail', function (response) {
                        contactInfo = contactInfo + '-' + response;

                        this.verify.equal(contactInfo, email + '-' + phone);
                    });
                });
            });
        });
    });


}
