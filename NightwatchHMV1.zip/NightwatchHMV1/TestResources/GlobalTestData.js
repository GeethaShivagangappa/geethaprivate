module.exports = {
    TestingEnvironment: 'QA',
    //TestingEnvironment: 'UAT',
    shortWait:5000,
    longWait:10000,
    urlHarmoniseQA: 'https://securemercerqa.www.marshinc.net/content/mercer-bbc/uk/en/provisioning/login.html',
    urlHarmoniseUAT: 'https://stg.mercerharmonise.mercer.com/content/mercer-bbc/uk/en/provisioning/login.html',
    usersQA: {
        normalUser: { username: 'zoetisqa09.eptest.admin2@gisqa.mercer.com', password: 'Welcome12', changedPassword: 'Welcome21'},
        changePasswordUser: { username: 'zoetisqa09.eptest.admin2@gisqa.mercer.com', password: 'Welcome12', changedPassword: 'Welcome21'},
        user1:  { username: 'msdua01.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},
        User2:  { username: 'q2qa04.eptest.admin2@gisqa.mercer.com', password: 'Welcome2'},
        user3:  { username: 'q2qa03.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},
        user11:  { username: 'rambollqa019.eptest.admin2@gisqa.mercer.com', password: 'Welcome4'},
        user4:  { username: 'hcaqa09.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},
        newUserLogin: { username: 'q2qa12.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},

newUserLogin1: { username: 'hcaqa09.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},
        returningUserLogin:{ username: 'q2qa12.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},


    },
    usersUAT: {
        normalUser: { username: 'ballinaua60.eptest.admin2@gisqa.mercer.com', password: 'Welcome2', changedPassword: 'Welcome1'},
        changePasswordUser: { username: 'ballinaua60.eptest.admin2@gisqa.mercer.com', password: 'Welcome2', changedPassword: 'Welcome1'},
        user2:  { username: 'ballinaua58.eptest.admin2@gisqa.mercer.com', password: 'Welcome1'},
        user12:  { username: '', password: 'Welcome2'},

},


    //Calendar locators
    ddMonth: {selector: 'select.ui-datepicker-month'},
    ddYear: {selector: 'select.ui-datepicker-year'},
    daySelector: {locateStrategy:'xpath', selector: '//*[@data-handler="selectDay"]//a[text()="<<day>>"]'},
    monthSelector: {locateStrategy:'xpath', selector: '//*[@class="ui-datepicker-month"]//option[@value="<<month>>"]'},
    yearSelector: {locateStrategy:'xpath', selector: '//*[@class="ui-datepicker-month"]//option[@value="<<year>>"]'}
}
